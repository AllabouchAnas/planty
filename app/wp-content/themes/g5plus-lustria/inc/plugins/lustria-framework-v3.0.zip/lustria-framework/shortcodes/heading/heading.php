<?php
if (!defined('ABSPATH')) {
	die('-1');
}
class WPBakeryShortCode_GSF_Heading extends G5P_ShortCode_Base {

}